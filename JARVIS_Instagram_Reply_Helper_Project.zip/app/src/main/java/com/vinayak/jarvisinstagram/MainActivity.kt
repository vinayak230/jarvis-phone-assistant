package com.vinayak.jarvisinstagram

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var chatInput: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(13, 18, 32))
        }
        val title = TextView(this).apply {
            text = "JARVIS • Instagram Reply Helper"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Paste the latest messages below. This starter version suggests replies locally; it does not read Instagram DMs automatically."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 14)
        }
        chatInput = EditText(this).apply {
            hint = "Paste the recent conversation here…"
            minLines = 5
            gravity = Gravity.TOP
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(31, 39, 58))
            setPadding(14, 14, 14, 14)
        }
        val generate = Button(this).apply {
            text = "Suggest replies"
            setOnClickListener { suggestReplies() }
        }
        val floating = Button(this).apply {
            text = "Enable floating JARVIS button"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                }
            }
        }
        result = TextView(this).apply {
            text = "Reply suggestions will appear here."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 18, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(chatInput, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(generate)
        root.addView(floating)
        val scroll = ScrollView(this)
        scroll.addView(result)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun suggestReplies() {
        val text = chatInput.text.toString().trim().lowercase()
        val suggestions = when {
            text.isBlank() -> listOf("Pehle recent chat paste kar, phir main suggestions banaunga.")
            listOf("busy", "later", "baad me", "kaam hai").any { text.contains(it) } ->
                listOf("Theek hai, jab free ho tab baat kar lena 🙂",
                       "No worries, apna kaam aaram se kar lo.")
            listOf("hi", "hello", "hey", "hii").any { text.endsWith(it) } ->
                listOf("Hey, kaisi ho? Kaafi time ho gaya baat nahi hui.",
                       "Hii, hope sab achha chal raha hai 🙂")
            listOf("sorry", "hurt", "upset", "gussa", "naraz").any { text.contains(it) } ->
                listOf("Main tumhari baat samajhna chahta hoon. Agar tum comfortable ho, toh calmly baat kar sakte hain.",
                       "Mera intention tumhe pressure dena nahi hai. Main bas honestly baat karna chahta hoon.")
            listOf("no", "mat", "stop", "don't", "dont").any { text.contains(it) } ->
                listOf("Theek hai, main tumhari baat aur space respect karunga.")
            else ->
                listOf("Achha, samjha 🙂 Aur batao, phir kya hua?",
                       "Haha, achha 😄 Tumhara din kaisa ja raha hai?",
                       "Main samajh raha hoon. Tum is baare mein aur bataogi?")
        }
        result.text = suggestions.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n\n") +
            "\n\nNote: These are simple offline starter suggestions, not AI-generated or based on automatic DM access."
    }
}
